package com.catalog;

import java.util.ArrayList;

import javax.persistence.Entity;

@Entity
public class Catalog {
      //private @Id @GeneratedValue Long id;
      private int custId;
	  private String name;
      public Catalog(){}
      public int getCustId()
      {
    	  return this.custId;
      }
      public String getName()
      {
    	  return this.name;
      }
      
      public Catalog(String name){
    	  this.name=name;
      }
      public Catalog(String name,int id){
    	  this.name=name;
    	  this.custId=id;
      }

      public void test() 
      {
    	  System.out.println("Test Method");      
      }
      public ArrayList<String>getCatalogList()
      {
      ArrayList<String> data=new ArrayList<String>();
      data.add("books");
      data.add("pencils");
      data.add("erasers");
	  return data;
      
      }
}