package com.enterpriseOrder;

public class OrdersForEnterpriseConfig {

}
