package com.dservice;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ServiceController {
	@PostMapping("/api/service/provision")
	String postService(@RequestBody String data)
	{
		return "Data posted "+data;
	}
	
	@PostMapping("/api/service/test-qos")
	String postService1(@RequestBody String data)
	{
		return "Data posted "+data;
	}
	
	@PutMapping("/api/service/disable/{connectionId}")
	String putService(@PathVariable int id)
	{
		return "Data updated "+id;
	}
	@PutMapping("/api/service/hold/{connectionId}")
	String putService1(@PathVariable int id)
	{
		return "Data updated "+id;
	}
	@PutMapping("/api/service/resume/{connectionId}")
	String putService2(@PathVariable int id)
	{
		return "Data updated "+id;
	}
}
	
