package com.dservice;

public class ServiceConfig {

}
