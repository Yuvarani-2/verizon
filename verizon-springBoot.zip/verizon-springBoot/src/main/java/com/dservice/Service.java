package com.dservice;

import java.util.ArrayList;

import javax.persistence.Entity;
@Entity
public class Service{
	 //private @Id @GeneratedValue Long id;
    private int connectionId;
	  private String name;
    public Service(){}
    public int getConnectionId()
    {
  	  return this.connectionId;
    }
    public String getName()
    {
  	  return this.name;
    }
    
    public Service(String name){
  	  this.name=name;
    }
    public Service(String name,int id){
  	  this.name=name;
  	  this.connectionId=id;
    }

    public void test() 
    {
  	  System.out.println("Test Method");      
    }
    public ArrayList<String>getOrderList()
    {
    ArrayList<String> data=new ArrayList<String>();
    data.add("books");
    data.add("pencils");
    data.add("erasers");
	  return data;
    
    }

}

