package com.enterprise;

public class Enterpriseconfig {

}
