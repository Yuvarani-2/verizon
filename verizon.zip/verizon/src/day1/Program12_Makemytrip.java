package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program12_Makemytrip {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		  Thread.sleep(3000);
		  WebDriver driver=new ChromeDriver();
		  Thread.sleep(3000);  
		  driver.navigate().to("https://www.makemytrip.com/");
		  Thread.sleep(3000); 
		  driver.manage().window().maximize();
		  JavascriptExecutor js=(JavascriptExecutor)driver;
		   
		  js.executeScript("document.elementFromPoint(0,0).click()");
		    
	driver.findElement(By.className("lbl_input")).click();
		  driver.findElement(By.className("react-autosuggest__input--open")).sendKeys("pune");
		  Thread.sleep(3000); 	  
		  driver.findElements(By.className("calc60")).get(0).click();
		  driver.findElement(By.className("lbl_input")).click(); 
		  driver.findElement(By.className("react-autosuggest__input--open")).sendKeys("chandigarh");
		  Thread.sleep(3000); 
		  driver.findElements(By.className("calc60")).get(0).click();
		  
		  
		  
	}

}
