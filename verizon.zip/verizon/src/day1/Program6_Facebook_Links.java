package day1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program6_Facebook_Links {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		  Thread.sleep(3000);
		  WebDriver driver=new ChromeDriver();
		  Thread.sleep(3000);  
		  driver.navigate().to("https://www.facebook.com/");
		  Thread.sleep(3000); 
		  driver.manage().window().maximize();
		  Thread.sleep(3000); 
		 //driver.findElement(By.linkText("Forgotten password?")).click();
	   // driver.findElement(List<A>partialLinkText("pass")).click();
		List<WebElement>tags=driver.findElements(By.tagName("input"));
		System.out.println(tags.size());
	}

}
