package day1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program11_Oyorooms {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		  Thread.sleep(3000);
		  WebDriver driver=new ChromeDriver();
		  Thread.sleep(3000);  
		  driver.navigate().to("https://www.oyorooms.com/");
		  Thread.sleep(3000); 
		  driver.manage().window().maximize();
		  driver.findElement(By.className("datePickerDesktop--home")).click();
		//  driver.findElement(By.className("DateRangePicker__PaginationArrow--next")).click();
		 // Thread.sleep(3000);
		 // driver.findElement(By.className("DateRangePicker__PaginationArrow--next")).click();
		  //Thread.sleep(3000);
		 // driver.findElement(By.className("DateRangePicker__PaginationArrow--next")).click();
	   	  for(int num=1;num<=3;num++)
	   	  {
	   		Thread.sleep(3000); 
	   		driver.findElement(By.className("DateRangePicker__PaginationArrow--next")).click();
	   		
	   	  }
	   	List<WebElement>dates= driver.findElements(By.className("DateRangePicker__DateLabel"));
		for(WebElement d:dates)
		  {
			  if(d.getText().equals("2")||d.getText().equals("3"))
			  {
				  Thread.sleep(3000); 
				  d.click();
				 
				  if(d.getText().equals("3"))
					  
				  break;
			  }
	}

	}}
