package day1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Program8_Dropdown {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		  Thread.sleep(3000);
		  WebDriver driver=new ChromeDriver();
		  Thread.sleep(3000);  
		  driver.navigate().to("https://itera-qa.azurewebsites.net/home/automation");
		  Thread.sleep(3000); 
		  driver.manage().window().maximize();
		  Thread.sleep(3000);
		  WebElement  nameBox=driver.findElement(By.id("name"));
		  nameBox.sendKeys("Selinium");
		  WebElement  phoneBox=driver.findElement(By.id("phone"));
		  phoneBox.sendKeys("1234567890");
		  WebElement  emailBox=driver.findElement(By.id("email"));
		  emailBox.sendKeys("abc@gmail.com");
		  WebElement  passwordBox=driver.findElement(By.id("password"));
		  passwordBox.sendKeys("12345");
		  WebElement  addressBox=driver.findElement(By.id("address"));
		  addressBox.sendKeys("Verizon,Chennai");
		  WebElement opBox=driver.findElement(By.id("male"));
		  opBox.click();
		//  String[] a = {"monday","wednesday","friday","sunday"};
		  //for(String a1:a)
		  //{
			//  driver.findElement(By.id(a1)).click();
		  //}
		  List<WebElement> tags=driver.findElements(By.tagName("input"));
		  for(int index=0;index<tags.size();index++)
		  {
			  if(index==8||index==10||index==12||index==14)
			  tags.get(index).click();
			  if (index==14)
				  break;
		  }
		  WebElement country =driver.findElement(By.className("custom-select"));
		  Select obj=new Select(country);
		  obj.selectByIndex(6);
		  Thread.sleep(3000);
		  obj.selectByVisibleText("Sweden");
		  Thread.sleep(3000);
		  obj.selectByValue("10");
		}	
	}

