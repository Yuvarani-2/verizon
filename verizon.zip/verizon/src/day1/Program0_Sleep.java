package day1;

public class Program0_Sleep {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
     System.out.println("one");
     Thread.sleep(3000);
     System.out.println("two");
     Thread.sleep(3000);
     System.out.println("three");
     Thread.sleep(3000);
     System.out.println("four");
     Thread.sleep(3000);
     System.out.println("five");
	}

}
