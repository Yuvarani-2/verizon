package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program9_GetMethods {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		  Thread.sleep(3000);
		  WebDriver driver=new ChromeDriver();
		  Thread.sleep(3000);  
		  driver.navigate().to("https://www.facebook.com/");
		  Thread.sleep(3000); 
		  driver.manage().window().maximize();
		  Thread.sleep(3000);
		  WebElement login=driver.findElement(By.name("login"));
		  System.out.println(login);
		  System.out.println(login.getAttribute("data-testid"));
		  System.out.println(login.getCssValue("color"));
		  System.out.println(login.getLocation());
		  System.out.println("*****************");
		  System.out.println(login.getTagName());
		  System.out.println(login.getText());
		  System.out.println(login.getRect().getHeight());
	}
}

