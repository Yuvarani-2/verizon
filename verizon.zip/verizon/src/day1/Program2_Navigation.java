package day1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program2_Navigation {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		  System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		  Thread.sleep(3000);
		  WebDriver driver=new ChromeDriver();
		  Thread.sleep(3000);  
		  driver.navigate().to("https://www.geeksforgeeks.org/");
		  Thread.sleep(3000);  
		  driver.manage().window().maximize();
		  driver.navigate().to("https://www.geeksforgeeks.org/array-data-structure/?ref=lbp");
		  Thread.sleep(3000);  
		  driver.navigate().back();
		  Thread.sleep(3000); 
		  driver.navigate().forward();
		  Thread.sleep(3000); 
		  driver.navigate().refresh();
		  Thread.sleep(3000); 
		  driver.close();
		  
		  }

}
