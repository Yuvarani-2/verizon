package day1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program1_BasicJava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
    WebDriver driver=new ChromeDriver();
    driver.get("https://www.geeksforgeeks.org/");
	}

}


