package day2;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pro13_Screeshot {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		  Thread.sleep(3000);
		  WebDriver driver=new ChromeDriver();
		  Thread.sleep(3000);  
		  driver.navigate().to("https://www.geeksforgeeks.org/");
		  Thread.sleep(3000); 
		  
		  File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		 // FileUtils.copyFile(src, new File("./image.png"));
		  FileUtils.copyFile(src, new File("./image.jpg"));
		  
	}

}
