package day2;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pro7_AlertHandle {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		  Thread.sleep(3000);
		  WebDriver driver=new ChromeDriver();
		  Thread.sleep(3000);  
		  driver.navigate().to("https://the-internet.herokuapp.com/javascript_alerts");
		  Thread.sleep(3000); 
		  driver.manage().window().maximize();
		  Thread.sleep(3000);
		  
		  driver.findElement(By.xpath("//*[text()='Click for JS Alert']")).click();
		  Alert alertWindow=driver.switchTo().alert();
		  System.out.println(alertWindow.getText());
		  alertWindow.accept();
		  
		  driver.findElement(By.xpath("//*[@id=\"content\"]/div/ul/li[2]/button")).click();
		  Alert confirmWindow=driver.switchTo().alert();
		  System.out.println(confirmWindow.getText());
		  confirmWindow.dismiss();
		  
		  driver.findElement(By.xpath("//*[@id=\"content\"]/div/ul/li[3]/button")).click();
		  Alert promptWindow=driver.switchTo().alert();
		  System.out.println(promptWindow.getText());
		  Thread.sleep(3000);
		  promptWindow.sendKeys("hello");
		  promptWindow.accept();
		  
	}

}
