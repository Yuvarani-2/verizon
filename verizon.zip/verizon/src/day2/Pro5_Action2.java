package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Pro5_Action2 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		  Thread.sleep(3000);
		  WebDriver driver=new ChromeDriver();
		  Thread.sleep(3000);  
		  driver.navigate().to("https://jqueryui.com/droppable/");
		  Thread.sleep(3000); 
		  driver.manage().window().maximize();
		  Thread.sleep(3000);
		  JavascriptExecutor js=(JavascriptExecutor)driver;
		  js.executeScript("window.scrollBy(0,50)");
		  WebElement frameTag=driver.findElement(By.className("demo-frame"));
		  driver.switchTo().frame(frameTag);
		 
	     
		  WebElement dg=driver.findElement(By.id("draggable"));
		 
		  WebElement dp=driver.findElement(By.id("droppable"));
		  Actions act=new Actions(driver);
		  act.dragAndDrop(dg,dp).build().perform();
	}

}
