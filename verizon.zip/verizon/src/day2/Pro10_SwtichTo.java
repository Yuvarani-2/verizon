package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pro10_SwtichTo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		  Thread.sleep(3000);
		  WebDriver driver=new ChromeDriver();
		  Thread.sleep(3000);  
		  driver.navigate().to("https://www.geeksforgeeks.org/");
		  Thread.sleep(3000); 
		  driver.manage().window().maximize();
		  Thread.sleep(3000);
		  driver.findElement(By.linkText("Sign In")).click();
		  driver.switchTo().activeElement();
		  Thread.sleep(3000);
		  driver.findElement(By.id("luser")).sendKeys("abc@gmail.com");
		  Thread.sleep(3000);
		  driver.findElement(By.id("password")).sendKeys("123456");
		  Thread.sleep(3000);
		  driver.findElement(By.xpath("//*[@id=\"Login\"]/button")).click();		    
	}

}
