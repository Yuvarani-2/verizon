package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Pro4_Action {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		  Thread.sleep(3000);
		  WebDriver driver=new ChromeDriver();
		  Thread.sleep(3000);  
		  driver.navigate().to("https://www.amazon.in/");
		  Thread.sleep(3000); 
		  driver.manage().window().maximize();
		  Thread.sleep(3000);
		//  WebElement signin=driver.findElement(By.id("nav-link-accountList-nav-line-1"));
		  Actions act=new Actions(driver);
		 // act.moveToElement(signin).build().perform();
		  WebElement input=driver.findElement(By.id("twotabsearchtextbox"));
		  act.keyDown(Keys.SHIFT).build().perform();
		  input.sendKeys("hello");
		  Thread.sleep(3000);
		  act.keyUp(Keys.SHIFT).build().perform();
		  input.sendKeys("bye");
}
}
