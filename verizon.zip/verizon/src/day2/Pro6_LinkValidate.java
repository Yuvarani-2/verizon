package day2;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Pro6_LinkValidate {

	public static void main(String[] args) throws MalformedURLException, IOException {
		// TODO Auto-generated method stub
       HttpURLConnection conn=(HttpURLConnection)new URL("https://www.facebook.com/")
    		   .openConnection();
       conn.setRequestMethod("GET");
       conn.connect();
       System.out.println(conn.getResponseCode());
      int s=conn.getResponseCode();
       if (s==200)
       {
    	   System.out.println("link is working");
       }
       else
       {
    	   System.out.println("link is not working");
      }
	}
}  
       
       
       
       
	

