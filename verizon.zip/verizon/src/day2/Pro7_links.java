package day2;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class Pro7_links {

	public static void main(String[] args) throws MalformedURLException, IOException, InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		  Thread.sleep(3000);
		  WebDriver driver=new ChromeDriver();
		  Thread.sleep(3000);  
		  driver.navigate().to("https://www.tutorialspoint.com/");
		  Thread.sleep(3000); 
		  driver.manage().window().maximize();
		  Thread.sleep(3000); 
		 
		  WebElement footer=driver.findElement(By.tagName("footer"));
		  List<WebElement>links=footer.findElements(By.tagName("a"));
		 System.out.println(links.size());
		 for(WebElement a:links)
		 {
				 System.out.print(a.getText()+" ");
				 HttpURLConnection conn=(HttpURLConnection)new URL("href").openConnection();
			    		  
			       conn.setRequestMethod("GET");
			       conn.connect();
			      
			       if(conn.getResponseCode()==200)
			       {
			    	   System.out.println("Working");
			       }
			       else 
			       {
			       System.out.println("Not Working");
			       }
			 }
	   	}
}
