package testcases;

import org.testng.annotations.Test;

public class PriorityTes {
	@Test(priority=2)
	void MethodA()
	{
		System.out.println("MethodA");
	}
	@Test(priority=3)
	void MethodC()
	{
		System.out.println("MethodC");
	}
	@Test(priority=1)
	void MethodB()
	{
		System.out.println("MethodB");
	}

}
