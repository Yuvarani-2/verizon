package testcases;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.chrome.ChromeDriver;

public class MakeMyTrip {
	
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		 ChromeDriver driver=new ChromeDriver();
		 Thread.sleep(3000);
		 driver.navigate().to("https://www.makemytrip.com/");
		 Thread.sleep(3000);
		 driver.manage().window().maximize();
		 Thread.sleep(3000);
		 driver.findElement(By.id("username")).sendKeys("6381371910");
		 Thread.sleep(3000);

		 driver.findElement(By.xpath("//*[@data-cy='continueBtn']")).click();
		 Scanner sc=new Scanner(System.in);
		 int otp=sc.nextInt();
		 driver.findElement(By.name("otp")).sendKeys(otp+"");
		 Thread.sleep(3000);
		 driver.findElement(By.xpath("//span[text()='Login']")).click();
		 Thread.sleep(3000);
		 JavascriptExecutor js=(JavascriptExecutor)driver;
		 js.executeScript("document.elementFromPoint(0,0).click()");
	}
	

}
