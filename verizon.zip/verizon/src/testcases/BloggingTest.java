package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.Test;

public class BloggingTest {
	
	
	@Test
	void gfg() throws InterruptedException
	{  WebDriver driver=new ChromeDriver();
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");	
		 driver.navigate().to("https://www.geeksforgeeks.org/");
	
    	driver.manage().window().maximize();
    	Thread.sleep(3000);
    	driver.close();
    }
   
    @Test
	void w3() throws InterruptedException
	{WebDriver driver=new ChromeDriver();
    	System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");	
		 driver.navigate().to("https://www.w3schools.com/");
	
    	driver.manage().window().maximize();
    	Thread.sleep(3000);
    	driver.close();
    }
    @Test
   	void guru() throws InterruptedException
   	{ WebDriver driver=new ChromeDriver();
    	System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");	
   		 driver.navigate().to("https://www.guru99.com/");
   	
       	driver.manage().window().maximize();
       	Thread.sleep(3000);
       	driver.close();
       }
}
