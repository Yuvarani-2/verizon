package testcases;
//import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
//import org.testng.asserts.SoftAssert;
public class MobileTest {
	@BeforeClass
	void beforeclass()
	{
		System.out.println("beforeclass 1");
	}
	@AfterClass
	void afterclass()
	{
		System.out.println("afterclass 1");
	}
	@BeforeMethod
	void beforemethod()
	{
		System.out.println("beforemethod 1");
	}
	@AfterMethod
	void aftermethod()
	{
		System.out.println("aftermethod 1");
	}
	 @Test
      void login()
      {
    	 try {
    		 System.out.println("Mobile Login");
    	//  int num=10/0;
      }
    	 catch(Exception ex)
    	 {
    		 System.out.println("there is an exception");
    	 }
    	 }
	 @Test
	 void logout()
	 {
		 System.out.println("mobile logout");
		// boolean result=false;
		 //SoftAssert soft=new SoftAssert();
		 //soft.assertTrue(result);
		// boolean result=true; 
		 //Assert.assertTrue(result);
		// Assert.assertFalse(result);
		// Assert.assertEquals("equal", "equal");
		// Assert.assertEquals("equal", "not equal");
		 //System.out.println("byee");
		 //soft.assertAll();
	 }
}
