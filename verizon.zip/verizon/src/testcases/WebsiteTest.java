package testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

@Test
public class WebsiteTest {
	@BeforeSuite
	void beforesuite()
	{
		System.out.println("BeforeSuite");
	}
	@AfterSuite
	void aftersuite()
	{
		System.out.println("aftersuite");
	}
	@BeforeTest
	void beforetest()
	{
		System.out.println("beforetest");
	}
	@AfterTest
	void aftertest()
	{
		System.out.println("aftertest");
	}
	@BeforeClass
	void beforeclass()
	{
		System.out.println("beforeclass 2");
	}
	@AfterClass
	void afterclass()
	{
		System.out.println("afterclass 2");
	}
	@BeforeMethod
	void beforemethod()
	{
		System.out.println("beforemethod 2");
	}
	@AfterMethod
	void aftermethod()
	{
		System.out.println("aftermethod 2");
	}
	@Parameters({"username"})
	@Test(groups="loginTest")//(enabled=false)
	void login(String u)
	{
		System.out.println("Website login" +u);
	}
	@Test(dataProvider="getdata")
	void logout(String username,String password)
	{
		System.out.println("Website logout" +username+" " +password);
	}
	@DataProvider
	Object[][]getdata(){
		Object[][]data=new Object[3][2];
		data[0][0]="User1";
		data[0][1]="pass1";
		data[1][0]="User2";
		data[1][1]="pass2";
		data[2][0]="User3";
		data[2][1]="pass3";
		return data;
	}
    
}
