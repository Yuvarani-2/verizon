package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ShoppingTest {
	
	
	@Test
	void amazon() throws InterruptedException
	{WebDriver driver=new ChromeDriver();
		System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");	
		 driver.navigate().to("https://www.amazon.in/");
	
    	driver.manage().window().maximize();
    	Thread.sleep(3000);
    	driver.close();
    }
   
    @Test
	void flip() throws InterruptedException
	{WebDriver driver=new ChromeDriver();
    	System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");	
		 driver.navigate().to("https://www.flipkart.com/");
	
    	driver.manage().window().maximize();
    	Thread.sleep(3000);
    	driver.close();
    }
}
