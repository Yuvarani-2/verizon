package day3;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Project1_Wait {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		 
	 ChromeDriver driver=new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));  
		  driver.navigate().to("https://www.geeksforgeeks.org/");
		
		  driver.manage().window().maximize();
		  Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				 .withTimeout(Duration.ofSeconds(30))
				 .pollingEvery(Duration.ofSeconds(5))
				 .ignoring(NoSuchElementException.class);
		//  WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(1));
		  WebDriverWait wait1= new WebDriverWait(driver,Duration.ofSeconds(5));	  
 wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("Sign In")))).click();			  
wait1.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("luser")))).sendKeys("abc@gmail.com");
wait1.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("password")))).sendKeys("123456");		  
	   // driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	//    driver.findElement(By.linkText("Sign In")).click();
		 // driver.switchTo().activeElement();
	
		
		
		  //driver.findElement(By.id("password")).sendKeys("123456");
		 
wait1.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id=\"Login\"]/button")))).click();		    
	}

}
