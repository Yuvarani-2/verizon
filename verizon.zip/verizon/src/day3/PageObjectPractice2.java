package day3;

import org.openqa.selenium.chrome.ChromeDriver;

import objects.LoginPage2;

public class PageObjectPractice2 {
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		     System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		 
		     ChromeDriver driver=new ChromeDriver();
		     Thread.sleep(3000);
			 driver.navigate().to("https://www.geeksforgeeks.org/");
			 Thread.sleep(3000);
			 driver.manage().window().maximize();
			 Thread.sleep(3000);
			 LoginPage2 obj=new LoginPage2(driver);
			 obj.getSignInBtn().click();	}

}
