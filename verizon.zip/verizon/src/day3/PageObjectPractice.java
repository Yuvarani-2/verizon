package day3;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;

import objects.LoginPage;

public class PageObjectPractice {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		     System.setProperty("webdriver.chrome.driver","C:\\verizon\\chromedriver.exe");
		 
		     ChromeDriver driver=new ChromeDriver();
		     Thread.sleep(3000);
			 driver.navigate().to("https://www.geeksforgeeks.org/");
			 Thread.sleep(3000);
			 driver.manage().window().maximize();
			 Thread.sleep(3000);
			 LoginPage obj=new LoginPage(driver);
			 obj.getSignInBtn(driver).click();	}

}
