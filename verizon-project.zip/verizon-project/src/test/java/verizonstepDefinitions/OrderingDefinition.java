package verizonstepDefinitions;

public class OrderingDefinition {

}
