package verizonstepDefinitions;

import io.cucumber.java.en.*;

public class CatalogDefinition {
	@Given("User is on the Catalog API Page1")
	public void user_is_on_the_catalog_api_page1() {
	    // Write code here that turns the phrase above into concrete actions
	 System.out.println("given 1");
	}

	@When("User wants to {string} api catalog")
	public void user_wants_to_api_catalog(String string) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("when 1");
	}

	@Then("User can access the catalog")
	public void user_can_access_the_catalog() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("then 1");
	}

	@Given("User is on the Catalog API Page2")
	public void user_is_on_the_catalog_api_page2() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("given 1");
	}

	@When("User wants to {string} api catalog {string}")
	public void user_wants_to_api_catalog(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("when 2");
	}



}
