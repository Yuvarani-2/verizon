package cucumberoptions;

import static org.junit.Assert.assertTrue;
import org.junit.runner.RunWith;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


import org.junit.Test;

	@CucumberOptions(features="src/test/java/features",glue="verizonstepDefinitions",
	tags="@catalogTest")
	public class V_TestRunner extends AbstractTestNGCucumberTests {

		
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
